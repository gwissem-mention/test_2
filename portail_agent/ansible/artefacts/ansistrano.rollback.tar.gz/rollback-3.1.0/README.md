Further details on Ansistrano
-----------------------------

If you want to know more about Ansistrano, please check the [complete Ansistrano docs](https://github.com/ansistrano/deploy/blob/master/README.md)
